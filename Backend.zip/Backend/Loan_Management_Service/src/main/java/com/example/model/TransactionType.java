package com.example.model;

public enum TransactionType {
    DISBURSEMENT,
    REPAYMENT,
    FAILED
}