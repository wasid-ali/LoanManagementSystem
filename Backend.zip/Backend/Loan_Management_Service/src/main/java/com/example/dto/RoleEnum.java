package com.example.dto;

public enum RoleEnum {
	CUSTOMER, LOAN_OFFICER, ADMIN
}
