package com.example.dto;

public enum LoanApplicationStatus {
	APPLIED,
    REJECTED,
    ACCEPTED,
    PENDING,
    APPROVED,
    ACTIVE,
    PAID_OFF
}
