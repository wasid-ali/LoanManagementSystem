import React, { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { UserContext } from '../context/UserContext';

const HomeLoan = () => {
    const { user, setUser } = useContext(UserContext);
    const navigate = useNavigate();

    const handleApply = () => {
        setUser({ ...user, productName: 'Home' });
        navigate('/loan-data');
    };

    return (
        <div>
            <h2>Home Loan Details</h2>
            <p>Some details about home loan...</p>
            <button onClick={handleApply}>Apply Now</button>
        </div>
    );
};

export default HomeLoan;