// import React, { useContext, useState } from 'react';
// import { useNavigate } from 'react-router-dom';
// import { UserContext } from '../context/UserContext';

// const SignUp = () => {
//   const [email, setEmail] = useState('');
//   const navigate = useNavigate();
//   const { setUser } = useContext(UserContext);

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     setUser((prevUser) => ({ ...prevUser, email }));
//     navigate('/personal-details', { state: { email } });
//   };

//   return (
//     <div>
//       <h2>Sign Up</h2>
//       <form onSubmit={handleSubmit}>
//         <input
//           type="email"
//           name="email"
//           value={email}
//           onChange={(e) => setEmail(e.target.value)}
//           placeholder="Enter your email"
//           required
//         />
//         <button type="submit">Submit</button>
//       </form>
//     </div>
//   );
// };

// export default SignUp;



import React, { useContext, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { UserContext } from '../context/UserContext';
import axios from 'axios';

const SignUp = () => {
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otpVerified, setOtpVerified] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();
  const { setUser } = useContext(UserContext);

  const handleEmailSubmit = (e) => {
    e.preventDefault();
    axios.post('http://localhost:8082/users/sendotp', { recipient: email })
      .then(response => {
        if (response.data === 'OTP sent successfully to ' + email) {
          setOtpSent(true);
          setErrorMessage('');
        } else {
          setErrorMessage('Error sending OTP. Please try again.');
        }
      })
      .catch(error => {
        console.error('There was an error sending the OTP!', error);
        setErrorMessage('Error sending OTP. Please try again.');
      });
  };

  const handleOtpSubmit = (e) => {
    e.preventDefault();
    axios.post('http://localhost:8082/users/api/email/verifyotp', { email, otp })
      .then(response => {
        if (response.data === 'OTP Verified Successfully') {
          setOtpVerified(true);
          setUser((prevUser) => ({ ...prevUser, email }));
          navigate('/personal-details', { state: { email } });
        } else {
          setErrorMessage('Invalid OTP. Please try again.');
        }
      })
      .catch(error => {
        console.error('There was an error verifying the OTP!', error);
        setErrorMessage('Error verifying OTP. Please try again.');
      });
  };

  return (
    <div>
      <h2>Sign Up</h2>
      {!otpSent ? (
        <form onSubmit={handleEmailSubmit}>
          <input
            type="email"
            name="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter your email"
            required
          />
          <button type="submit">Submit</button>
        </form>
      ) : !otpVerified ? (
        <form onSubmit={handleOtpSubmit}>
          <p>OTP sent to {email}. Please enter the OTP below to verify your email.</p>
          <input
            type="text"
            name="otp"
            value={otp}
            onChange={(e) => setOtp(e.target.value)}
            placeholder="Enter OTP"
            required
          />
          <button type="submit">Verify OTP</button>
        </form>
      ) : null}
      {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
    </div>
  );
};

export default SignUp;
