import React, { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { UserContext } from '../context/UserContext';

const GoldLoan = () => {
    const { user, setUser } = useContext(UserContext);
    const navigate = useNavigate();

    const handleApply = () => {
        setUser({ ...user, productName: 'Gold' });
        navigate('/loan-data');
    };

    return (
        <div>
            <h2>Gold Loan Details</h2>
            <p>Some details about gold loan...</p>
            <button onClick={handleApply}>Apply Now</button>
        </div>
    );
};

export default GoldLoan;
