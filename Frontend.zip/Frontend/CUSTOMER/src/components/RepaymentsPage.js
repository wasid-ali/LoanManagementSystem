import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
 
const RepaymentsPage = () => {
    const { loanId } = useParams();
    const [repayments, setRepayments] = useState([]);
 
    useEffect(() => {
        axios.get(`http://localhost:9191/api/repayments/loan/${loanId}`)
            .then(response => {
                setRepayments(response.data);
            })
            .catch(error => {
                console.error('There was an error fetching the repayments!', error);
            });
    }, [loanId]);
 
    const generatePDF = () => {
        const doc = new jsPDF();
        doc.text(`Repayments for Loan ID: ${loanId}`, 10, 10);
 
        const headers = ['Repayment ID', 'Amount', 'Repayment Date', 'Status'];
       
        const rows = repayments.map(item => [
            item.id,
            item.amount,
            item.repaymentDate,
            item.status
        ]);
 
        doc.autoTable({
            startY: 20,
            head: [headers],
            body: rows,
        });
 
        doc.save(`repayments_loan_${loanId}.pdf`);
    };
 
    return (
        <div>
            <h2>Repayments for Loan ID: {loanId}</h2>
            {repayments.length > 0 ? (
                <div>
                    <button onClick={generatePDF}>Download Repayments</button>
                    <table>
                        <thead>
                            <tr>
                                <th>Repayment ID</th>
                                <th>Amount</th>
                                <th>Repayment Date</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            {repayments.map(repayment => (
                                <tr key={repayment.id}>
                                    <td>{repayment.id}</td>
                                    <td>{repayment.amount}</td>
                                    <td>{repayment.repaymentDate}</td>
                                    <td>{repayment.status}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            ) : (
                <p>No Repayments Available</p>
            )}
        </div>
    );
};
 
export default RepaymentsPage;