// import React, { useContext, useEffect, useState } from 'react';
// import { UserContext } from '../context/UserContext';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';
// import Navbar from './Navbar';
// import { jsPDF } from 'jspdf';
// import 'jspdf-autotable';
// import './styles.css';

// const CustomerDashboard = () => {
//     const { user, logout } = useContext(UserContext);
//     const [userData, setUserData] = useState({});
//     const [loanApplications, setLoanApplications] = useState([]);
//     const [activeLoans, setActiveLoans] = useState([]);
//     const [paidOffLoans, setPaidOffLoans] = useState([]);
//     const [selectedLoan, setSelectedLoan] = useState(null);
//     const [paymentModalVisible, setPaymentModalVisible] = useState(false);
//     const [filteredActiveLoans, setFilteredActiveLoans] = useState([]);
//     const [filteredPaidOffLoans, setFilteredPaidOffLoans] = useState([]);
//     const [filters, setFilters] = useState({
//         startDate: '',
//         endDate: '',
//         loanManager: '',
//         vendor: ''
//     });
//     const navigate = useNavigate();

//     useEffect(() => {
//         if (user.userId) {
//             axios.get(`http://localhost:8082/users/readOne/${user.userId}`)
//                 .then(response => {
//                     setUserData(response.data);
//                 })
//                 .catch(error => {
//                     console.error('There was an error fetching the user data!', error);
//                 });

//             axios.get('http://localhost:8083/loan-applications/read')
//                 .then(response => {
//                     const userApplications = response.data.filter(application => application.user.user_id === user.userId);
//                     setLoanApplications(userApplications);
//                 })
//                 .catch(error => {
//                     console.error('There was an error fetching the loan applications!', error);
//                 });

//             axios.get(`http://localhost:9191/api/loans/customer/${user.userId}`)
//                 .then(response => {
//                     const loans = response.data;
//                     const detailedLoans = loans.map(async (loan) => {
//                         const managerResponse = await axios.get(`http://localhost:8084/managers/readOne/${loan.loanManagerId}`);
//                         const repaymentResponse = await axios.get(`http://localhost:9191/api/repayments/calculate-repayment-amount/${loan.id}`);
//                         loan.manager = managerResponse.data.user;
//                         loan.vendor = managerResponse.data.vendor;
//                         loan.totalRepaymentAmount = repaymentResponse.data;
//                         return loan;
//                     });
//                     Promise.all(detailedLoans).then(loans => {
//                         setActiveLoans(loans.filter(loan => loan.status === 'active'));
//                         setPaidOffLoans(loans.filter(loan => loan.status === 'paid_off'));
//                         setFilteredActiveLoans(loans.filter(loan => loan.status === 'active'));
//                         setFilteredPaidOffLoans(loans.filter(loan => loan.status === 'paid_off'));
//                     });
//                 })
//                 .catch(error => {
//                     console.error('There was an error fetching the loans!', error);
//                 });
//         }
//     }, [user]);

//     useEffect(() => {
//         filterLoans();
//     }, [filters, activeLoans, paidOffLoans]);

//     const handleApply = (loanType) => {
//         navigate(`/apply/${loanType}`);
//     };

//     const handleViewDetails = (applicationId, status) => {
//         const statusMap = {
//             'Application_Submitted': '/tracking1/',
//             'Submit_Docs': '/tracking2/',
//             'Docs_Submitted': '/tracking3/',
//             'Resubmit_Docs': '/tracking4/',
//             'Docs_Resubmitted': '/tracking5/',
//             'Loan_Approved': '/tracking6/',
//         };
//         navigate(statusMap[status] ? `${statusMap[status]}${applicationId}` : alert('This feature is currently under development.'));
//     };

//     const handleLogout = () => {
//         logout();
//         navigate('/login');
//     };

//     const handlePayEMI = (loan) => {
//         setSelectedLoan(loan);
//         setPaymentModalVisible(true);
//     };

//     const handleRaiseQuery = (loanId) => {
//         navigate(`/raise-query/${loanId}`);
//     };

//     const handleViewTransactions = (loanId) => {
//         navigate(`/transactions/${loanId}`);
//     };

//     const handleViewRepayments = (loanId) => {
//         navigate(`/repayments/${loanId}`);
//     };

//     const generatePDF = (loan, data, type) => {
//         const doc = new jsPDF();
//         doc.text(`User: ${userData.first_name} ${userData.last_name}`, 10, 10);
//         doc.text(`Loan ID: ${loan.id}`, 10, 20);
//         doc.text(`Amount: ${loan.amount}`, 10, 30);
//         doc.text(`Interest Rate: ${loan.interestRate}`, 10, 40);
//         doc.text(`Repayable Amount: ${loan.repayableAmount}`, 10, 50);
//         doc.text(`Start Date: ${loan.startDate}`, 10, 60);
//         doc.text(`End Date: ${loan.endDate}`, 10, 70);

//         const headers = type === 'transactions'
//             ? ['Transaction ID', 'Amount', 'Type', 'Transaction Date']
//             : ['Repayment ID', 'Amount', 'Repayment Date', 'Status'];

//         const rows = data.map(item => type === 'transactions'
//             ? [item.id, item.amount, item.type, item.transactionDate]
//             : [item.id, item.amount, item.repaymentDate, item.status]
//         );

//         doc.autoTable({
//             startY: 80,
//             head: [headers],
//             body: rows,
//         });

//         doc.save(`${type}_loan_${loan.id}.pdf`);
//     };

//     const handleFilterChange = (e) => {
//         const { name, value } = e.target;
//         setFilters({
//             ...filters,
//             [name]: value
//         });
//     };

//     const filterLoans = () => {
//         const filteredActive = activeLoans.filter(loan => {
//             const matchesStartDate = filters.startDate ? new Date(loan.startDate) >= new Date(filters.startDate) : true;
//             const matchesEndDate = filters.endDate ? new Date(loan.endDate) <= new Date(filters.endDate) : true;
//             const matchesManager = filters.loanManager ? (loan.manager.first_name + ' ' + loan.manager.last_name).toLowerCase().includes(filters.loanManager.toLowerCase()) : true;
//             const matchesVendor = filters.vendor ? loan.vendor.vendor_name.toLowerCase().includes(filters.vendor.toLowerCase()) : true;
//             return matchesStartDate && matchesEndDate && matchesManager && matchesVendor;
//         });

//         const filteredPaidOff = paidOffLoans.filter(loan => {
//             const matchesStartDate = filters.startDate ? new Date(loan.startDate) >= new Date(filters.startDate) : true;
//             const matchesEndDate = filters.endDate ? new Date(loan.endDate) <= new Date(filters.endDate) : true;
//             const matchesManager = filters.loanManager ? (loan.manager.first_name + ' ' + loan.manager.last_name).toLowerCase().includes(filters.loanManager.toLowerCase()) : true;
//             const matchesVendor = filters.vendor ? loan.vendor.vendor_name.toLowerCase().includes(filters.vendor.toLowerCase()) : true;
//             return matchesStartDate && matchesEndDate && matchesManager && matchesVendor;
//         });

//         setFilteredActiveLoans(filteredActive);
//         setFilteredPaidOffLoans(filteredPaidOff);
//     };

//     return (
//         <div style={{ padding: '20px' }}>
//             <Navbar />
//             {userData.first_name && <h1>Hello {userData.first_name}</h1>}
//             <button onClick={handleLogout} style={{ float: 'right', marginTop: '-50px' }}>Logout</button>
//             <div style={{ display: 'flex', justifyContent: 'space-around', marginTop: '20px' }}>
//                 <div className="card">
//                     <h2>Home Loan</h2>
//                     <button onClick={() => handleApply('home')}>Apply Now</button>
//                 </div>
//                 <div className="card">
//                     <h2>Personal Loan</h2>
//                     <button onClick={() => handleApply('personal')}>Apply Now</button>
//                 </div>
//                 <div className="card">
//                     <h2>Gold Loan</h2>
//                     <button onClick={() => handleApply('gold')}>Apply Now</button>
//                 </div>
//             </div>
//             <div style={{ marginTop: '40px' }}>
//                 <h2>Track Your Loan Application</h2>
//                 {loanApplications.length > 0 ? (
//                     <table>
//                         <thead>
//                             <tr>
//                                 <th>Application ID</th>
//                                 <th>Product Type</th>
//                                 <th>Amount Required</th>
//                                 <th>Status</th>
//                                 <th>Action</th>
//                             </tr>
//                         </thead>
//                         <tbody>
//                             {loanApplications.map(application => (
//                                 <tr key={application.application_id}>
//                                     <td>{application.application_id}</td>
//                                     <td>{application.product.product_name}</td>
//                                     <td>{application.amount_required}</td>
//                                     <td>{application.status}</td>
//                                     <td>
//                                         <button onClick={() => handleViewDetails(application.application_id, application.status)}>View Details</button>
//                                     </td>
//                                 </tr>
//                             ))}
//                         </tbody>
//                     </table>
//                 ) : (
//                     <p>No Active Applications</p>
//                 )}
//             </div>
//             <div style={{ marginTop: '40px' }}>
//                 <h2>Your Active Loans</h2>
//                 <div>
//                     <label>
//                         Start Date:
//                         <input type="date" name="startDate" value={filters.startDate} onChange={handleFilterChange} />
//                     </label>
//                     <label>
//                         End Date:
//                         <input type="date" name="endDate" value={filters.endDate} onChange={handleFilterChange} />
//                     </label>
//                     <label>
//                         Loan Manager:
//                         <input type="text" name="loanManager" value={filters.loanManager} onChange={handleFilterChange} />
//                     </label>
//                     <label>
//                         Vendor:
//                         <input type="text" name="vendor" value={filters.vendor} onChange={handleFilterChange} />
//                     </label>
//                 </div>
//                 {filteredActiveLoans.length > 0 ? (
//                     <table>
//                         <thead>
//                             <tr>
//                                 <th>Loan ID</th>
//                                 <th>Amount</th>
//                                 <th>Start Date</th>
//                                 <th>End Date</th>
//                                 <th>Interest Rate</th>
//                                 <th>Repayable Amount</th>
//                                 <th>Manager</th>
//                                 <th>Vendor</th>
//                                 <th>Total Repayment Amount</th>
//                                 <th>Actions</th>
//                             </tr>
//                         </thead>
//                         <tbody>
//                             {filteredActiveLoans.map(loan => (
//                                 <tr key={loan.id}>
//                                     <td>{loan.id}</td>
//                                     <td>{loan.amount}</td>
//                                     <td>{loan.startDate}</td>
//                                     <td>{loan.endDate}</td>
//                                     <td>{loan.interestRate}%</td>
//                                     <td>{loan.repayableAmount}</td>
//                                     <td>{loan.manager.first_name} {loan.manager.last_name}</td>
//                                     <td>{loan.vendor.vendor_name}</td>
//                                     <td>{loan.totalRepaymentAmount}</td>
//                                     <td>
//                                         <button onClick={() => handleViewTransactions(loan.id)}>View Transactions</button>
//                                         <button onClick={() => handlePayEMI(loan)}>Pay EMI</button>
//                                         <button onClick={() => handleRaiseQuery(loan.id)}>Raise Query</button>
//                                         <button onClick={() => handleViewRepayments(loan.id)}>View Repayments</button>
//                                     </td>
//                                 </tr>
//                             ))}
//                         </tbody>
//                     </table>
//                 ) : (
//                     <p>No Active Loans</p>
//                 )}
//             </div>
//             <div style={{ marginTop: '40px' }}>
//                 <h2>Your Paid Off Loans</h2>
//                 {filteredPaidOffLoans.length > 0 ? (
//                     <table>
//                         <thead>
//                             <tr>
//                                 <th>Loan ID</th>
//                                 <th>Amount</th>
//                                 <th>Start Date</th>
//                                 <th>End Date</th>
//                                 <th>Interest Rate</th>
//                                 <th>Repayable Amount</th>
//                                 <th>Manager</th>
//                                 <th>Vendor</th>
//                                 <th>Total Repayment Amount</th>
//                                 <th>Actions</th>
//                             </tr>
//                         </thead>
//                         <tbody>
//                             {filteredPaidOffLoans.map(loan => (
//                                 <tr key={loan.id}>
//                                     <td>{loan.id}</td>
//                                     <td>{loan.amount}</td>
//                                     <td>{loan.startDate}</td>
//                                     <td>{loan.endDate}</td>
//                                     <td>{loan.interestRate}%</td>
//                                     <td>{loan.repayableAmount}</td>
//                                     <td>{loan.manager.first_name} {loan.manager.last_name}</td>
//                                     <td>{loan.vendor.vendor_name}</td>
//                                     <td>{loan.totalRepaymentAmount}</td>
//                                     <td>
//                                         <button onClick={() => handleViewTransactions(loan.id)}>View Transactions</button>
//                                     </td>
//                                 </tr>
//                             ))}
//                         </tbody>
//                     </table>
//                 ) : (
//                     <p>No Paid Off Loans</p>
//                 )}
//             </div>
//             {paymentModalVisible && (
//                 <PaymentModal
//                     loan={selectedLoan}
//                     onClose={() => setPaymentModalVisible(false)}
//                 />
//             )}
//         </div>
//     );
// };

// const PaymentModal = ({ loan, onClose }) => {
//     const [paymentOption, setPaymentOption] = useState('');
//     const [bankDetails, setBankDetails] = useState({});
//     const [cardDetails, setCardDetails] = useState({});
//     const [upiId, setUpiId] = useState('');
//     const [paymentSuccess, setPaymentSuccess] = useState(false);
//     const [lateFee, setLateFee] = useState(loan.lateFee);
//     const [prePaymentFee, setPrePaymentFee] = useState(loan.prePaymentFee);
//     const [monthlyPayments, setMonthlyPayments] = useState(0);
//     const [isFormValid, setIsFormValid] = useState(false);

//     useEffect(() => {
//         const currentDate = new Date();
//         const isBeforeTenth = currentDate.getDate() <= 10;
        
//         // Calculate the number of payments made in the current month
//         const paymentsInMonth = loan.repayments.filter(repayment => {
//             const repaymentDate = new Date(repayment.repaymentDate);
//             return repaymentDate.getMonth() === currentDate.getMonth() && repaymentDate.getFullYear() === currentDate.getFullYear();
//         }).length;

//         setMonthlyPayments(paymentsInMonth);

//         if (isBeforeTenth) {
//             setLateFee(0);
//         }

//         if (paymentsInMonth === 0) {
//             setPrePaymentFee(0);
//         } else if (paymentsInMonth > 0) {
//             setPrePaymentFee(loan.prePaymentFee);
//         }
//     }, [loan]);

//     useEffect(() => {
//         const validateForm = () => {
//             if (paymentOption === 'bank') {
//                 if (bankDetails.type === 'new') {
//                     return bankDetails.accountNumber && bankDetails.bankName && bankDetails.ifscCode;
//                 } else if (bankDetails.type === 'existing') {
//                     return true;
//                 }
//             } else if (paymentOption === 'card') {
//                 return cardDetails.number && cardDetails.expiry && cardDetails.name && cardDetails.cvv;
//             } else if (paymentOption === 'upi') {
//                 return upiId;
//             }
//             return false;
//         };
//         setIsFormValid(validateForm());
//     }, [paymentOption, bankDetails, cardDetails, upiId]);

//     const handlePayment = () => {
//         const paymentDetails = {
//             lateFee,
//             prePaymentFee,
//             // Include other necessary payment details here
//         };

//         // Depending on the paymentOption, collect the necessary details
//         if (paymentOption === 'bank') {
//             // Add bank details to paymentDetails
//         } else if (paymentOption === 'card') {
//             // Add card details to paymentDetails
//         } else if (paymentOption === 'upi') {
//             // Add UPI ID to paymentDetails
//         }

//         axios.post(`http://localhost:9191/api/repayments/${loan.id}`, paymentDetails)
//             .then(response => {
//                 setPaymentSuccess(true);
//             })
//             .catch(error => {
//                 console.error('Payment failed!', error);
//             });
//     };

//     return (
//         <div className="modal">
//             <div className="modal-content">
//                 <span className="close" onClick={onClose}>&times;</span>
//                 {paymentSuccess ? (
//                     <div>
//                         <h2>Payment Successful</h2>
//                         <p>Your payment has been processed successfully.</p>
//                         <button onClick={onClose}>Close</button>
//                     </div>
//                 ) : (
//                     <div>
//                         <h2>Pay EMI for Loan ID: {loan.id}</h2>
//                         <p>EMI Amount: {loan.emiamount}</p>
//                         <p>Late Fee: {lateFee}</p>
//                         <p>Prepayment Fee: {prePaymentFee}</p>
//                         <label>
//                             Payment Option:
//                             <select value={paymentOption} onChange={(e) => setPaymentOption(e.target.value)}>
//                                 <option value="">Select...</option>
//                                 <option value="bank">Bank Transfer</option>
//                                 <option value="card">Debit/Credit Card</option>
//                                 <option value="upi">UPI</option>
//                             </select>
//                         </label>
//                         {paymentOption === 'bank' && (
//                             <div>
//                                 <h3>Bank Transfer</h3>
//                                 <label>
//                                     <input type="radio" name="bank" value="new" onChange={(e) => setBankDetails({ ...bankDetails, type: 'new' })} /> New Bank Account
//                                 </label>
//                                 <label>
//                                     <input type="radio" name="bank" value="existing" onChange={(e) => setBankDetails({ ...bankDetails, type: 'existing' })} /> Existing Bank Account
//                                 </label>
//                                 {bankDetails.type === 'new' && (
//                                     <div>
//                                         <label>
//                                             Bank Account Number:
//                                             <input type="text" onChange={(e) => setBankDetails({ ...bankDetails, accountNumber: e.target.value })} />
//                                         </label>
//                                         <label>
//                                             Bank Name:
//                                             <input type="text" onChange={(e) => setBankDetails({ ...bankDetails, bankName: e.target.value })} />
//                                         </label>
//                                         <label>
//                                             IFSC Code:
//                                             <input type="text" onChange={(e) => setBankDetails({ ...bankDetails, ifscCode: e.target.value })} />
//                                         </label>
//                                     </div>
//                                 )}
//                             </div>
//                         )}
//                         {paymentOption === 'card' && (
//                             <div>
//                                 <h3>Card Payment</h3>
//                                 <label>
//                                     Card Number:
//                                     <input type="text" onChange={(e) => setCardDetails({...cardDetails, number: e.target.value})} />
//                                 </label>
//                                 <label>
//                                     Expiry Date:
//                                     <input type="text" onChange={(e) => setCardDetails({...cardDetails, expiry: e.target.value})} />
//                                 </label>
//                                 <label>
//                                     Cardholder Name:
//                                     <input type="text" onChange={(e) => setCardDetails({...cardDetails, name: e.target.value})} />
//                                 </label>
//                                 <label>
//                                     CVV:
//                                     <input type="text" onChange={(e) => setCardDetails({...cardDetails, cvv: e.target.value})} />
//                                 </label>
//                             </div>
//                         )}
//                         {paymentOption === 'upi' && (
//                             <div>
//                                 <h3>UPI Payment</h3>
//                                 <label>
//                                     UPI ID:
//                                     <input type="text" onChange={(e) => setUpiId(e.target.value)} />
//                                 </label>
//                             </div>
//                         )}
//                         <button onClick={handlePayment} disabled={!isFormValid}>Pay</button>
//                     </div>
//                 )}
//             </div>
//         </div>
//     );
// };

// export default CustomerDashboard;





import React, { useContext, useEffect, useState } from 'react';
import { UserContext } from '../context/UserContext';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import Navbar from './Navbar';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import './styles.css';
 
const CustomerDashboard = () => {
    const { user, logout } = useContext(UserContext);
    const [userData, setUserData] = useState({});
    const [loanApplications, setLoanApplications] = useState([]);
    const [activeLoans, setActiveLoans] = useState([]);
    const [paidOffLoans, setPaidOffLoans] = useState([]);
    const [selectedLoan, setSelectedLoan] = useState(null);
    const [paymentModalVisible, setPaymentModalVisible] = useState(false);
    const [filteredActiveLoans, setFilteredActiveLoans] = useState([]);
    const [filteredPaidOffLoans, setFilteredPaidOffLoans] = useState([]);
    const [filtersActive, setFiltersActive] = useState({
        startDate: '',
        endDate: '',
        loanManager: '',
        vendor: ''
    });
    const [filtersPaidOff, setFiltersPaidOff] = useState({
        startDate: '',
        endDate: '',
        loanManager: '',
        vendor: ''
    });
    const [currentPageActive, setCurrentPageActive] = useState(1);
    const [currentPagePaidOff, setCurrentPagePaidOff] = useState(1);
    const itemsPerPage = 5;
    const navigate = useNavigate();
 
    useEffect(() => {
        if (user.userId) {
            axios.get(`http://localhost:8082/users/readOne/${user.userId}`)
                .then(response => {
                    setUserData(response.data);
                })
                .catch(error => {
                    console.error('There was an error fetching the user data!', error);
                });
 
            axios.get('http://localhost:8083/loan-applications/read')
                .then(response => {
                    const userApplications = response.data.filter(application => application.user.user_id === user.userId);
                    setLoanApplications(userApplications);
                })
                .catch(error => {
                    console.error('There was an error fetching the loan applications!', error);
                });
 
            axios.get(`http://localhost:9191/api/loans/customer/${user.userId}`)
                .then(response => {
                    const loans = response.data;
                    const detailedLoans = loans.map(async (loan) => {
                        const managerResponse = await axios.get(`http://localhost:8084/managers/readOne/${loan.loanManagerId}`);
                        const repaymentResponse = await axios.get(`http://localhost:9191/api/repayments/calculate-repayment-amount/${loan.id}`);
                        loan.manager = managerResponse.data.user;
                        loan.vendor = managerResponse.data.vendor;
                        loan.totalRepaymentAmount = repaymentResponse.data;
                        return loan;
                    });
                    Promise.all(detailedLoans).then(loans => {
                        setActiveLoans(loans.filter(loan => loan.status === 'active'));
                        setPaidOffLoans(loans.filter(loan => loan.status === 'paid_off'));
                        setFilteredActiveLoans(loans.filter(loan => loan.status === 'active'));
                        setFilteredPaidOffLoans(loans.filter(loan => loan.status === 'paid_off'));
                    });
                })
                .catch(error => {
                    console.error('There was an error fetching the loans!', error);
                });
        }
    }, [user]);
 
    useEffect(() => {
        filterActiveLoans();
    }, [filtersActive, activeLoans]);
 
    useEffect(() => {
        filterPaidOffLoans();
    }, [filtersPaidOff, paidOffLoans]);
 
    const handleApply = (loanType) => {
        navigate(`/apply/${loanType}`);
    };
 
    const handleViewDetails = (applicationId, status) => {
        const statusMap = {
            'Application_Submitted': '/tracking1/',
            'Submit_Docs': '/tracking2/',
            'Docs_Submitted': '/tracking3/',
            'Resubmit_Docs': '/tracking4/',
            'Docs_Resubmitted': '/tracking5/',
            'Loan_Approved': '/tracking6/',
        };
        navigate(statusMap[status] ? `${statusMap[status]}${applicationId}` : alert('This feature is currently under development.'));
    };
 
    const handleLogout = () => {
        logout();
        navigate('/login');
    };
 
    const handlePayEMI = (loan) => {
        setSelectedLoan(loan);
        setPaymentModalVisible(true);
    };
 
    const handleRaiseQuery = (loanId, managerId) => {
        navigate(`/support?loanId=${loanId}&managerId=${managerId}`);
    };
 
    const handleViewTransactions = (loanId) => {
        navigate(`/transactions/${loanId}`);
    };
 
    const handleViewRepayments = (loanId) => {
        navigate(`/repayments/${loanId}`);
    };
 
    const generatePDF = (loan, data, type) => {
        const doc = new jsPDF();
        doc.text(`User: ${userData.first_name} ${userData.last_name}`, 10, 10);
        doc.text(`Loan ID: ${loan.id}`, 10, 20);
        doc.text(`Amount: ${loan.amount}`, 10, 30);
        doc.text(`Interest Rate: ${loan.interestRate}`, 10, 40);
        doc.text(`Repayable Amount: ${loan.repayableAmount}`, 10, 50);
        doc.text(`Start Date: ${loan.startDate}`, 10, 60);
        doc.text(`End Date: ${loan.endDate}`, 10, 70);
 
        const headers = type === 'transactions'
            ? ['Transaction ID', 'Amount', 'Type', 'Transaction Date']
            : ['Repayment ID', 'Amount', 'Repayment Date', 'Status'];
 
        const rows = data.map(item => type === 'transactions'
            ? [item.id, item.amount, item.type, item.transactionDate]
            : [item.id, item.amount, item.repaymentDate, item.status]
        );
 
        doc.autoTable({
            startY: 80,
            head: [headers],
            body: rows,
        });
 
        doc.save(`${type}_loan_${loan.id}.pdf`);
    };
 
    const handleFilterChange = (e, type) => {
        const { name, value } = e.target;
        if (type === 'active') {
            setFiltersActive({
                ...filtersActive,
                [name]: value
            });
        } else {
            setFiltersPaidOff({
                ...filtersPaidOff,
                [name]: value
            });
        }
    };
 
    const filterActiveLoans = () => {
        const filteredActive = activeLoans.filter(loan => {
            const matchesStartDate = filtersActive.startDate ? new Date(loan.startDate) >= new Date(filtersActive.startDate) : true;
            const matchesEndDate = filtersActive.endDate ? new Date(loan.endDate) <= new Date(filtersActive.endDate) : true;
            const matchesManager = filtersActive.loanManager ? (loan.manager.first_name + ' ' + loan.manager.last_name).toLowerCase().includes(filtersActive.loanManager.toLowerCase()) : true;
            const matchesVendor = filtersActive.vendor ? loan.vendor.vendor_name.toLowerCase().includes(filtersActive.vendor.toLowerCase()) : true;
            return matchesStartDate && matchesEndDate && matchesManager && matchesVendor;
        });
        setFilteredActiveLoans(filteredActive);
    };
 
    const filterPaidOffLoans = () => {
        const filteredPaidOff = paidOffLoans.filter(loan => {
            const matchesStartDate = filtersPaidOff.startDate ? new Date(loan.startDate) >= new Date(filtersPaidOff.startDate) : true;
            const matchesEndDate = filtersPaidOff.endDate ? new Date(loan.endDate) <= new Date(filtersPaidOff.endDate) : true;
            const matchesManager = filtersPaidOff.loanManager ? (loan.manager.first_name + ' ' + loan.manager.last_name).toLowerCase().includes(filtersPaidOff.loanManager.toLowerCase()) : true;
            const matchesVendor = filtersPaidOff.vendor ? loan.vendor.vendor_name.toLowerCase().includes(filtersPaidOff.vendor.toLowerCase()) : true;
            return matchesStartDate && matchesEndDate && matchesManager && matchesVendor;
        });
        setFilteredPaidOffLoans(filteredPaidOff);
    };
 
    const paginate = (items, pageNumber, itemsPerPage) => {
        const startIndex = (pageNumber - 1) * itemsPerPage;
        return items.slice(startIndex, startIndex + itemsPerPage);
    };
 
    const activeLoansPage = paginate(filteredActiveLoans, currentPageActive, itemsPerPage);
    const paidOffLoansPage = paginate(filteredPaidOffLoans, currentPagePaidOff, itemsPerPage);
 
    return (
        <div style={{ padding: '20px' }}>
            <Navbar />
            {userData.first_name && <h1>Hello {userData.first_name}</h1>}
            <button onClick={handleLogout} style={{ float: 'right', marginTop: '-50px' }}>Logout</button>
            <div style={{ display: 'flex', justifyContent: 'space-around', marginTop: '20px' }}>
                <div className="card">
                    <h2>Home Loan</h2>
                    <button onClick={() => handleApply('home')}>Apply Now</button>
                </div>
                <div className="card">
                    <h2>Personal Loan</h2>
                    <button onClick={() => handleApply('personal')}>Apply Now</button>
                </div>
                <div className="card">
                    <h2>Gold Loan</h2>
                    <button onClick={() => handleApply('gold')}>Apply Now</button>
                </div>
            </div>
            <div style={{ marginTop: '40px' }}>
                <h2>Track Your Loan Application</h2>
                {loanApplications.length > 0 ? (
                    <table>
                        <thead>
                            <tr>
                                <th>Application ID</th>
                                <th>Product Type</th>
                                <th>Amount Required</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {loanApplications.map(application => (
                                <tr key={application.application_id}>
                                    <td>{application.application_id}</td>
                                    <td>{application.product.product_name}</td>
                                    <td>{application.amount_required}</td>
                                    <td>{application.status}</td>
                                    <td>
                                        <button onClick={() => handleViewDetails(application.application_id, application.status)}>View Details</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                ) : (
                    <p>No Active Applications</p>
                )}
            </div>
            <div style={{ marginTop: '40px' }}>
                <h2>Your Active Loans</h2>
                <div>
                    <label>
                        Start Date:
                        <input type="date" name="startDate" value={filtersActive.startDate} onChange={(e) => handleFilterChange(e, 'active')} />
                    </label>
                    <label>
                        End Date:
                        <input type="date" name="endDate" value={filtersActive.endDate} onChange={(e) => handleFilterChange(e, 'active')} />
                    </label>
                    <label>
                        Loan Manager:
                        <input type="text" name="loanManager" value={filtersActive.loanManager} onChange={(e) => handleFilterChange(e, 'active')} />
                    </label>
                    <label>
                        Vendor:
                        <input type="text" name="vendor" value={filtersActive.vendor} onChange={(e) => handleFilterChange(e, 'active')} />
                    </label>
                </div>
                {filteredActiveLoans.length > 0 ? (
                    <>
                        <table>
                            <thead>
                                <tr>
                                    <th>Loan ID</th>
                                    <th>Amount</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Interest Rate</th>
                                    <th>Repayable Amount</th>
                                    <th>Manager</th>
                                    <th>Vendor</th>
                                    <th>Total Repayment Amount</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {activeLoansPage.map(loan => (
                                    <tr key={loan.id}>
                                        <td>{loan.id}</td>
                                        <td>{loan.amount}</td>
                                        <td>{loan.startDate}</td>
                                        <td>{loan.endDate}</td>
                                        <td>{loan.interestRate}%</td>
                                        <td>{loan.repayableAmount}</td>
                                        <td>{loan.manager.first_name} {loan.manager.last_name}</td>
                                        <td>{loan.vendor.vendor_name}</td>
                                        <td>{loan.totalRepaymentAmount}</td>
                                        <td>
                                            <button onClick={() => handleViewTransactions(loan.id)}>View Transactions</button>
                                            <button onClick={() => handlePayEMI(loan)}>Pay EMI</button>
                                            <button onClick={() => handleRaiseQuery(loan.id, loan.manager.user_id)}>Need Support</button>
                                            <button onClick={() => handleViewRepayments(loan.id)}>View Repayments</button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        <Pagination
                            itemsPerPage={itemsPerPage}
                            totalItems={filteredActiveLoans.length}
                            paginate={setCurrentPageActive}
                            currentPage={currentPageActive}
                        />
                    </>
                ) : (
                    <p>No Active Loans</p>
                )}
            </div>
            <div style={{ marginTop: '40px' }}>
                <h2>Your Paid Off Loans</h2>
                <div>
                    <label>
                        Start Date:
                        <input type="date" name="startDate" value={filtersPaidOff.startDate} onChange={(e) => handleFilterChange(e, 'paid_off')} />
                    </label>
                    <label>
                        End Date:
                        <input type="date" name="endDate" value={filtersPaidOff.endDate} onChange={(e) => handleFilterChange(e, 'paid_off')} />
                    </label>
                    <label>
                        Loan Manager:
                        <input type="text" name="loanManager" value={filtersPaidOff.loanManager} onChange={(e) => handleFilterChange(e, 'paid_off')} />
                    </label>
                    <label>
                        Vendor:
                        <input type="text" name="vendor" value={filtersPaidOff.vendor} onChange={(e) => handleFilterChange(e, 'paid_off')} />
                    </label>
                </div>
                {filteredPaidOffLoans.length > 0 ? (
                    <>
                        <table>
                            <thead>
                                <tr>
                                    <th>Loan ID</th>
                                    <th>Amount</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Interest Rate</th>
                                    <th>Repayable Amount</th>
                                    <th>Manager</th>
                                    <th>Vendor</th>
                                    <th>Total Repayment Amount</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {paidOffLoansPage.map(loan => (
                                    <tr key={loan.id}>
                                        <td>{loan.id}</td>
                                        <td>{loan.amount}</td>
                                        <td>{loan.startDate}</td>
                                        <td>{loan.endDate}</td>
                                        <td>{loan.interestRate}%</td>
                                        <td>{loan.repayableAmount}</td>
                                        <td>{loan.manager.first_name} {loan.manager.last_name}</td>
                                        <td>{loan.vendor.vendor_name}</td>
                                        <td>{loan.totalRepaymentAmount}</td>
                                        <td>
                                            <button onClick={() => handleViewTransactions(loan.id)}>View Transactions</button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        <Pagination
                            itemsPerPage={itemsPerPage}
                            totalItems={filteredPaidOffLoans.length}
                            paginate={setCurrentPagePaidOff}
                            currentPage={currentPagePaidOff}
                        />
                    </>
                ) : (
                    <p>No Paid Off Loans</p>
                )}
            </div>
            {paymentModalVisible && (
                <PaymentModal
                    loan={selectedLoan}
                    onClose={() => setPaymentModalVisible(false)}
                />
            )}
        </div>
    );
};
 
const Pagination = ({ itemsPerPage, totalItems, paginate, currentPage }) => {
    const pageNumbers = [];
 
    for (let i = 1; i <= Math.ceil(totalItems / itemsPerPage); i++) {
        pageNumbers.push(i);
    }
 
    return (
        <nav>
            <ul className="pagination">
                {pageNumbers.map(number => (
                    <li key={number} className={`page-item ${number === currentPage ? 'active' : ''}`}>
                        <a onClick={() => paginate(number)} href="#!" className="page-link">
                            {number}
                        </a>
                    </li>
                ))}
            </ul>
        </nav>
    );
};
 
const PaymentModal = ({ loan, onClose }) => {
    const [paymentOption, setPaymentOption] = useState('');
    const [bankDetails, setBankDetails] = useState({});
    const [cardDetails, setCardDetails] = useState({});
    const [upiId, setUpiId] = useState('');
    const [paymentSuccess, setPaymentSuccess] = useState(false);
    const [lateFee, setLateFee] = useState(loan.lateFee);
    const [prePaymentFee, setPrePaymentFee] = useState(loan.prePaymentFee);
    const [monthlyPayments, setMonthlyPayments] = useState(0);
    const [isFormValid, setIsFormValid] = useState(false);
 
    useEffect(() => {
        const currentDate = new Date();
        const isBeforeTenth = currentDate.getDate() <= 10;
       
        // Calculate the number of payments made in the current month
        const paymentsInMonth = loan.repayments.filter(repayment => {
            const repaymentDate = new Date(repayment.repaymentDate);
            return repaymentDate.getMonth() === currentDate.getMonth() && repaymentDate.getFullYear() === currentDate.getFullYear();
        }).length;
 
        setMonthlyPayments(paymentsInMonth);
 
        if (isBeforeTenth) {
            setLateFee(0);
        }
 
        if (paymentsInMonth === 0) {
            setPrePaymentFee(0);
        } else if (paymentsInMonth > 0) {
            setPrePaymentFee(loan.prePaymentFee);
        }
    }, [loan]);
 
    useEffect(() => {
        const validateForm = () => {
            if (paymentOption === 'bank') {
                if (bankDetails.type === 'new') {
                    return bankDetails.accountNumber && bankDetails.bankName && bankDetails.ifscCode;
                } else if (bankDetails.type === 'existing') {
                    return true;
                }
            } else if (paymentOption === 'card') {
                return cardDetails.number && cardDetails.expiry && cardDetails.name && cardDetails.cvv;
            } else if (paymentOption === 'upi') {
                return upiId;
            }
            return false;
        };
        setIsFormValid(validateForm());
    }, [paymentOption, bankDetails, cardDetails, upiId]);
 
    const handlePayment = () => {
        const paymentDetails = {
            lateFee,
            prePaymentFee,
            // Include other necessary payment details here
        };
 
        // Depending on the paymentOption, collect the necessary details
        if (paymentOption === 'bank') {
            // Add bank details to paymentDetails
        } else if (paymentOption === 'card') {
            // Add card details to paymentDetails
        } else if (paymentOption === 'upi') {
            // Add UPI ID to paymentDetails
        }
 
        axios.post(`http://localhost:9191/api/repayments/${loan.id}`, paymentDetails)
            .then(response => {
                setPaymentSuccess(true);
            })
            .catch(error => {
                console.error('Payment failed!', error);
            });
    };
 
    return (
        <div className="modal">
            <div className="modal-content">
                <span className="close" onClick={onClose}>&times;</span>
                {paymentSuccess ? (
                    <div>
                        <h2>Payment Successful</h2>
                        <p>Your payment has been processed successfully.</p>
                        <button onClick={onClose}>Close</button>
                    </div>
                ) : (
                    <div>
                        <h2>Pay EMI for Loan ID: {loan.id}</h2>
                        <p>EMI Amount: {loan.emiamount}</p>
                        <p>Late Fee: {lateFee}</p>
                        <p>Prepayment Fee: {prePaymentFee}</p>
                        <label>
                            Payment Option:
                            <select value={paymentOption} onChange={(e) => setPaymentOption(e.target.value)}>
                                <option value="">Select...</option>
                                <option value="bank">Bank Transfer</option>
                                <option value="card">Debit/Credit Card</option>
                                <option value="upi">UPI</option>
                            </select>
                        </label>
                        {paymentOption === 'bank' && (
                            <div>
                                <h3>Bank Transfer</h3>
                                <label>
                                    <input type="radio" name="bank" value="new" onChange={(e) => setBankDetails({ ...bankDetails, type: 'new' })} /> New Bank Account
                                </label>
                                <label>
                                    <input type="radio" name="bank" value="existing" onChange={(e) => setBankDetails({ ...bankDetails, type: 'existing' })} /> Existing Bank Account
                                </label>
                                {bankDetails.type === 'new' && (
                                    <div>
                                        <label>
                                            Bank Account Number:
                                            <input type="text" onChange={(e) => setBankDetails({ ...bankDetails, accountNumber: e.target.value })} />
                                        </label>
                                        <label>
                                            Bank Name:
                                            <input type="text" onChange={(e) => setBankDetails({ ...bankDetails, bankName: e.target.value })} />
                                        </label>
                                        <label>
                                            IFSC Code:
                                            <input type="text" onChange={(e) => setBankDetails({ ...bankDetails, ifscCode: e.target.value })} />
                                        </label>
                                    </div>
                                )}
                            </div>
                        )}
                        {paymentOption === 'card' && (
                            <div>
                                <h3>Card Payment</h3>
                                <label>
                                    Card Number:
                                    <input type="text" onChange={(e) => setCardDetails({...cardDetails, number: e.target.value})} />
                                </label>
                                <label>
                                    Expiry Date:
                                    <input type="text" onChange={(e) => setCardDetails({...cardDetails, expiry: e.target.value})} />
                                </label>
                                <label>
                                    Cardholder Name:
                                    <input type="text" onChange={(e) => setCardDetails({...cardDetails, name: e.target.value})} />
                                </label>
                                <label>
                                    CVV:
                                    <input type="text" onChange={(e) => setCardDetails({...cardDetails, cvv: e.target.value})} />
                                </label>
                            </div>
                        )}
                        {paymentOption === 'upi' && (
                            <div>
                                <h3>UPI Payment</h3>
                                <label>
                                    UPI ID:
                                    <input type="text" onChange={(e) => setUpiId(e.target.value)} />
                                </label>
                            </div>
                        )}
                        <button onClick={handlePayment} disabled={!isFormValid}>Pay</button>
                    </div>
                )}
            </div>
        </div>
    );
};
 
export default CustomerDashboard;


