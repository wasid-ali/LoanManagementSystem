import React, { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { UserContext } from '../context/UserContext';

const PersonalLoan = () => {
  const { user, setUser } = useContext(UserContext);
  const navigate = useNavigate();

  const handleApply = () => {
    setUser({ ...user, productName: 'Personal' });
    navigate('/loan-data');
  };

  return (
    <div>
      <h2>Personal Loan Details</h2>
      <p>Some details about personal loan...</p>
      <button onClick={handleApply}>Apply Now</button>
    </div>
  );
};

export default PersonalLoan;
