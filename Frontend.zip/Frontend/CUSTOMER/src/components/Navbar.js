// src/components/Navbar.js
import React, { useContext, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { UserContext } from '../context/UserContext';
import axios from 'axios';

const Navbar = () => {
  const { user, logout } = useContext(UserContext);
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState([]);
  const [dropdownOpen, setDropdownOpen] = useState(false);

  useEffect(() => {
    if (user && user.userId) {
      axios.get(`http://localhost:8086/notifications/read?userId=${user.userId}`)
        .then(response => {
          const allNotifications = response.data;
          const openNotifications = allNotifications.filter(notification => notification.status === 'OPEN');
          setNotifications(openNotifications);

        })
        .catch(error => {
          console.error('Error fetching notifications:', error);
        });
    }
  }, [user]);

  const handleLogout = () => {
    logout();
    navigate('/logout');
  };

  const handleNavigation = (path) => {
    navigate(path);
  };

  const markAsRead = (notificationId) => {
    axios.put(`http://localhost:8086/notifications/update/${notificationId}`, { status: 'CLOSED' })
      .then(() => {
        setNotifications(notifications.filter(notification => notification.notificationId !== notificationId));
      })
      .catch(error => {
        console.error('Error marking notification as read:', error);
      });
  };
  

  return (
    <nav style={navStyle}>
      <h1 style={logoStyle}>Loan Application</h1>
      <div style={buttonContainerStyle}>
        <button onClick={() => handleNavigation('/dashboard')}>Homepage</button>
        <button onClick={() => handleNavigation('/support')}>Support</button>
        <button onClick={() => handleNavigation('/myprofile')}>My Profile</button>
        <div style={{ position: 'relative' }}>
          <button onClick={() => setDropdownOpen(!dropdownOpen)}>Notifications</button>
          {dropdownOpen && (
            <div style={dropdownStyle}>
              {notifications.map(notification => (
                <div key={notification.notificationId} style={notificationItemStyle}>
                  <p style={{ color: '#000' }}>{notification.notificationBody}</p>
                  <button onClick={() => markAsRead(notification.notificationId)}>Mark as Read</button>
                </div>
              ))}
              <button onClick={() => handleNavigation('/notifications')}>View All Notifications</button>
            </div>
          )}
        </div>
        <button onClick={handleLogout}>Logout</button>
      </div>
    </nav>
  );
};

const navStyle = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  padding: '10px 20px',
  backgroundColor: '#333',
  color: '#fff'
};

const logoStyle = {
  margin: 0
};

const buttonContainerStyle = {
  display: 'flex',
  gap: '10px'
};

const dropdownStyle = {
  position: 'absolute',
  top: '100%',
  right: 0,
  backgroundColor: '#fff',
  boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
  borderRadius: '4px',
  padding: '10px',
  zIndex: 1000
};

const notificationItemStyle = {
  marginBottom: '10px',
  color: '#000' // Set text color to black
};

export default Navbar;
