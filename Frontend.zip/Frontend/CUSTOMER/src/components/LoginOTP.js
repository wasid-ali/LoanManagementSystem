import React, { useState, useContext} from 'react';
import { useNavigate } from 'react-router-dom';
import UserService from '../services/userService';
import { UserContext } from '../context/UserContext';

const LoginOTP = () => {
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();
  const { setUser } = useContext(UserContext);

  const handleSendOTP = (e) => {
    e.preventDefault();
    UserService.sendOTP({ recipient: email })
      .then((response) => {
        setOtpSent(true);
        setErrorMessage('');
      })
      .catch((error) => {
        setErrorMessage('No User exists with this Email Id');
      });
  };

  const handleVerifyOTP = (e) => {
    e.preventDefault();
    UserService.loginOTPVerify({ email, otp })
      .then((response) => {
        if (response.data) {
          setUser({ userId: response.data.user_id });
          navigate('/dashboard');
        } else {
          setErrorMessage('Incorrect OTP');
        }
      })
      .catch((error) => {
        console.log(error);
        setErrorMessage('Incorrect OTP');
      });
  };
  

  return (
    <div>
      <h2>Login with OTP</h2>
      <form onSubmit={handleSendOTP}>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Enter your email"
          required
        />
        <button type="submit">Send OTP</button>
      </form>
      {otpSent && (
        <form onSubmit={handleVerifyOTP}>
          <input
            type="text"
            value={otp}
            onChange={(e) => setOtp(e.target.value)}
            placeholder="Enter OTP"
            required
          />
          <button type="submit">Submit</button>
        </form>
      )}
      {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
      <button onClick={() => navigate('/login')}>Login through Password</button>
      <button onClick={() => navigate('/forgot-password')}>Forgot Password</button>
      <button onClick={() => navigate('/signup')}>Sign Up</button>
    </div>
  );
};

export default LoginOTP;
