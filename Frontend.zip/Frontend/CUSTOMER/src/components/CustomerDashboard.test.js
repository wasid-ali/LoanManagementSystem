// import React from 'react';
// import { render, screen, fireEvent, waitFor } from '@testing-library/react';
// import { BrowserRouter } from 'react-router-dom';
// import axios from 'axios';
// import CustomerDashboard from './CustomerDashboard';
// import { UserContext } from '../context/UserContext';

// jest.mock('axios');

// const user = {
//   userId: 1,
// };

// const userData = {
//   first_name: 'John',
//   last_name: 'Doe',
// };

// const loanApplications = [
//   {
//     application_id: 1,
//     product: { product_name: 'Home Loan' },
//     amount_required: 500000,
//     status: 'Application_Submitted',
//   },
// ];

// const activeLoans = [
//   {
//     id: 1,
//     amount: 100000,
//     startDate: '2023-01-01',
//     endDate: '2024-01-01',
//     interestRate: 5,
//     repayableAmount: 105000,
//     manager: { first_name: 'Jane', last_name: 'Smith' },
//     vendor: { vendor_name: 'Vendor 1' },
//     totalRepaymentAmount: 110000,
//     status: 'active',
//   },
// ];

// const paidOffLoans = [
//   {
//     id: 2,
//     amount: 150000,
//     startDate: '2022-01-01',
//     endDate: '2023-01-01',
//     interestRate: 4,
//     repayableAmount: 156000,
//     manager: { first_name: 'John', last_name: 'Doe' },
//     vendor: { vendor_name: 'Vendor 2' },
//     totalRepaymentAmount: 160000,
//     status: 'paid_off',
//   },
// ];

// const mockNavigate = jest.fn();

// jest.mock('react-router-dom', () => ({
//   ...jest.requireActual('react-router-dom'),
//   useNavigate: () => mockNavigate,
// }));

// describe('CustomerDashboard', () => {
//   beforeEach(() => {
//     axios.get.mockImplementation((url) => {
//       if (url.includes('/users/readOne/1')) {
//         return Promise.resolve({ data: userData });
//       }
//       if (url.includes('/loan-applications/read')) {
//         return Promise.resolve({ data: loanApplications });
//       }
//       if (url.includes('/api/loans/customer/1')) {
//         return Promise.resolve({ data: activeLoans.concat(paidOffLoans) });
//       }
//       if (url.includes('/managers/readOne/')) {
//         return Promise.resolve({ data: { user: { first_name: 'Jane', last_name: 'Smith' }, vendor: { vendor_name: 'Vendor 1' } } });
//       }
//       if (url.includes('/api/repayments/calculate-repayment-amount/')) {
//         return Promise.resolve({ data: 110000 });
//       }
//       return Promise.reject(new Error('not found'));
//     });
//   });

//   afterEach(() => {
//     jest.clearAllMocks();
//   });

//   test('renders CustomerDashboard and fetches data', async () => {
//     render(
//       <UserContext.Provider value={{ user }}>
//         <BrowserRouter>
//           <CustomerDashboard />
//         </BrowserRouter>
//       </UserContext.Provider>
//     );

//     await waitFor(() => {
//       expect(screen.getByText('Hello John')).toBeInTheDocument();
//     });

//     expect(axios.get).toHaveBeenCalledTimes(5); // Ensure all required API calls are made

//     // Verify loan applications table
//     expect(screen.getByText('Track Your Loan Application')).toBeInTheDocument();
//     expect(screen.getByText('Application ID')).toBeInTheDocument();
//     expect(screen.getByText('Product Type')).toBeInTheDocument();
//     expect(screen.getByText('Amount Required')).toBeInTheDocument();
//     expect(screen.getByText('Status')).toBeInTheDocument();
//     expect(screen.getByText('Action')).toBeInTheDocument();
//     expect(screen.getByText('Home Loan')).toBeInTheDocument();

//     // Verify active loans table
//     expect(screen.getByText('Your Active Loans')).toBeInTheDocument();
//     expect(screen.getByText('Loan ID')).toBeInTheDocument();
//     expect(screen.getByText('Amount')).toBeInTheDocument();
//     expect(screen.getByText('Interest Rate')).toBeInTheDocument();
//     expect(screen.getByText('Repayable Amount')).toBeInTheDocument();
//     expect(screen.getByText('Manager')).toBeInTheDocument();
//     expect(screen.getByText('Vendor')).toBeInTheDocument();

//     // Verify paid off loans table
//     expect(screen.getByText('Your Paid Off Loans')).toBeInTheDocument();
//     expect(screen.getByText('Loan ID')).toBeInTheDocument();
//     expect(screen.getByText('Amount')).toBeInTheDocument();
//     expect(screen.getByText('Interest Rate')).toBeInTheDocument();
//     expect(screen.getByText('Repayable Amount')).toBeInTheDocument();
//     expect(screen.getByText('Manager')).toBeInTheDocument();
//     expect(screen.getByText('Vendor')).toBeInTheDocument();
//   });

//   test('handles Apply Now button click', async () => {
//     render(
//       <UserContext.Provider value={{ user }}>
//         <BrowserRouter>
//           <CustomerDashboard />
//         </BrowserRouter>
//       </UserContext.Provider>
//     );

//     await waitFor(() => {
//       expect(screen.getByText('Hello John')).toBeInTheDocument();
//     });

//     fireEvent.click(screen.getByText('Apply Now', { selector: 'button' }));

//     expect(mockNavigate).toHaveBeenCalledWith('/apply/home');
//   });

//   test('handles View Details button click', async () => {
//     render(
//       <UserContext.Provider value={{ user }}>
//         <BrowserRouter>
//           <CustomerDashboard />
//         </BrowserRouter>
//       </UserContext.Provider>
//     );

//     await waitFor(() => {
//       expect(screen.getByText('Hello John')).toBeInTheDocument();
//     });

//     fireEvent.click(screen.getByText('View Details'));

//     expect(mockNavigate).toHaveBeenCalledWith('/tracking1/1');
//   });

//   test('handles Logout button click', async () => {
//     const mockLogout = jest.fn();

//     render(
//       <UserContext.Provider value={{ user, logout: mockLogout }}>
//         <BrowserRouter>
//           <CustomerDashboard />
//         </BrowserRouter>
//       </UserContext.Provider>
//     );

//     await waitFor(() => {
//       expect(screen.getByText('Hello John')).toBeInTheDocument();
//     });

//     fireEvent.click(screen.getByText('Logout'));

//     expect(mockLogout).toHaveBeenCalled();
//     expect(mockNavigate).toHaveBeenCalledWith('/login');
//   });
// });
